// small interactive touches
document.addEventListener('DOMContentLoaded', function(){
  // nothing fancy for static demo, placeholder for enhancements
  console.log('edukasi indonesia 2025 - demo site');
});